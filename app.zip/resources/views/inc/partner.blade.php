    <!-- Divider: Clients -->
    <section class="clients bg-theme-colored">
        <div class="container pt-0 pb-0">
          <div class="row">
            <div class="col-md-12">
              <!-- Section: Clients -->
              <div class="owl-carousel-6col clients-logo transparent text-center">
                <div class="item"> <a href="#"><b>Speech and Language Therapist</b></a></div>
                <div class="item"> <a href="#"><b>Literacy Intervention Centre</b></a></div>
                <div class="item"> <a href="#"><b>Occupational therapist</b></a></div>
                <div class="item"> <a href="#"><b>Hospitals/paediatric centres</b></a></div>
                <div class="item"> <a href="#"><b>Extra-curricular Support Centres</b></a></div>
                <div class="item"> <a href="#"><b>Speech and Language Therapist</b></a></div>
                <div class="item"> <a href="#"><b>Literacy Intervention Centre</b></a></div>
                <div class="item"> <a href="#"><b>Occupational therapist</b></a></div>
                <div class="item"> <a href="#"><b>Hospitals/paediatric centres</b></a></div>
                <div class="item"> <a href="#"><b>Extra-curricular Support Centres</b></a></div>
              </div>
            </div>
          </div>
        </div>
      </section>
