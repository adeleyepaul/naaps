<?php $__env->startComponent('mail::message'); ?>

# Thank you for your message

<strong>Name:</strong> <?php echo e($data['name']); ?><br>
<strong>Email:</strong> <?php echo e($data['email']); ?><br>
<strong>Phone No:</strong> <?php echo e($data['phone']); ?><br>
<strong>Title:</strong> <?php echo e($data['title']); ?><br>

<strong>Message</strong>

<?php echo e($data['message']); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH /home/naaplldv/public_html/resources/views/emails/pages/contact-form.blade.php ENDPATH**/ ?>