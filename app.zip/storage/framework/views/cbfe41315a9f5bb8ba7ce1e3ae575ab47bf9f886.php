  <!-- Header -->
  <header id="header" class="header">
    
    <div class="header-nav">
      <div class="header-nav-wrapper navbar-scrolltofixed bg-white">
        <div class="container">
          <nav id="menuzord-right" class="menuzord default">
            <a class="menuzord-brand pull-left flip xs-pull-center" href="./">
              <img src="images/new_logo.jpeg">
            </a>
            <ul class="menuzord-menu">
              <li><a href="./">Home</a></li>
              <li><a>Services</a>
                <ul class="dropdown">
                  <li><a href="/psychological_services">Psychological services</a></li>
                  <li><a href="/workforce_dev">Workforce development</a></li>
                  <li><a href="/services_for_parents">Services for parents</a></li>
                  <li><a href="/services_to_school">Services to schools</a></li>
                </ul>
              </li>
              <li><a href="/about">About</a>
                <ul class="dropdown">
                  <li><a href="/team">Our team</a></li>
                  <li><a href="#">Blog</a></li>
                </ul>
              </li>
              <li><a href="/contact">Contact</a></li>
              <li><a href="/career">Career</a></li>
            </ul>
          </nav>
        </div>
      </div>
    </div>
  </header>
<?php /**PATH C:\xampp\htdocs\app\resources\views/inc/navbar.blade.php ENDPATH**/ ?>