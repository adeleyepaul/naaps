<?php $__env->startSection('content'); ?>
    <!-- Start main-content -->
  <div class="main-content">

    <!-- Section: inner-header -->
    <section class="inner-header divider parallax layer-overlay overlay-dark-5" data-bg-img="images/naaps/service.jpeg">
      <div class="container pt-70 pb-50">
        <!-- Section Content -->
        <div class="section-content">
          <div class="row"> 
            <div class="col-md-12">
              <ul class="breadcrumb white">
                <li><a class="text-white" href="/">Home</a></li>
                <li class="active">Service Details</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Section: Services -->
    <section>
      <div class="container">
        <div class="row mtli-row-clearfix">
          <div class="col-sm-6 col-md-8 col-lg-8">
            <div class="campaign bg-silver-light maxwidth500 mb-30">
              <div class="thumb">
                <img src="images/services/single-Service6.html" alt="" class="img-fullwidth">
                <div class="campaign-overlay"></div>
              </div>
            </div>
            <div class="event-details">
                <div class="col-md-12">
                    <img src="images/Capture2.png" alt="">
                  </div>
            </div>
          </div>
          <div class="col-sm-6 col-md-4 col-lg-4">
            <div class="sidebar sidebar-right mt-sm-30">
              <div class="widget">
                <h5 class="widget-title line-bottom">All Services</h5>
                <ul class="list-divider list-border list check">
                  <li><a href="#">Consultancy</a></li>
                  <li><a href="#">Psychological Support</a></li>
                  <li><a href="#">Workforce</a></li>
                  <li><a href="#">Community</a></li>
                  <li><a href="#">Sources of Referral</a></li>
                  <li><a href="#">Intervention/ Therapeutic Intervention</a></li>
                  <li><a href="#">Assessment/ Casework of Children & Young People/ Adults</a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Divider: Clients -->
    
  </div>
  <!-- end main-content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/pages/service.blade.php ENDPATH**/ ?>